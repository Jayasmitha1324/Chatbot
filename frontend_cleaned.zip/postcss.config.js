// postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},       // ✅ correct plugin name for v3
    autoprefixer: {},
  },
};
