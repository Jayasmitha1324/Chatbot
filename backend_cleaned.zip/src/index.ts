// src/index.ts
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const cookieParser = require("cookie-parser");
dotenv.config();

const authRouter = require("./routes/authRoutes");
const projectRouter = require("./routes/projectRoutes");
const chatRouter = require("./routes/chatRoutes");
const filesRouter = require("./routes/filesRoutes");
const promptRouter = require("./routes/promptRoutes");

const errorHandler = require("./middleware/errorMiddleware");

const app = express();

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));
app.use(cors({ origin: true, credentials: true })); // ensure allow credentials
app.use(cookieParser());

// mount routers
app.use("/api/auth", authRouter);
app.use("/api/projects", projectRouter); // project endpoints
app.use("/api/chat", chatRouter);        // chat endpoints
app.use("/api/files", filesRouter);      // file upload endpoints
app.use("/api/projects", promptRouter);  // prompts at /api/projects/:projectId/prompts

// error handler (last)
app.use(errorHandler);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

export {};